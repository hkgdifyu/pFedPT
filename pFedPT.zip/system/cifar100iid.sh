#!/bin/bash


# ===============================================================horizontal(Cifar100-iid)======================================================================


# rm ../dataset/Cifar100/config.json
# cd ../dataset/
# nohup python -u generate_cifar10.py noniid - dir 50 0.1 2 > log10/cifar10_dir0.1_dataset.out 2>&1
# cd ../system/



nohup python -u main.py  --arv1 "noniid" --arv2 "-" --arv3 "dir" --arv4  "50" --arv5  "0.1" --arv6  "2"  --device_id  0 -algo MOON  -m cnn -lbs 16 -nc 50 -jr 0.2   -pls 5 -gr 2 -ls 5 -np 2 -data "Cifar10" -nb 10 --pt_learning_rate 1 --learning_decay 1  --momentum 0.5 > log10/cifar10_dir0.1_FedAvg_0.2.txt 2>&1 &